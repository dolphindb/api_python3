import setuptools

setuptools.setup(name='dolphindb',
    version='0.1.7',
    install_requires=[
        "numpy",
        "pandas",
    ],
    author='DolphinDB, Inc.',
    author_email='support@dolphindb.com',
    license='DolphinDB',
    description='A C++ boosted DolphinDB API based on Pybind11',
    packages=setuptools.find_packages(),
    include_package_data=True,
    python_requires='~=3.6',
    classifiers=[
        "Programming Language :: Python :: 3.6",
        "Operating System :: OS Independent"
    ],)
